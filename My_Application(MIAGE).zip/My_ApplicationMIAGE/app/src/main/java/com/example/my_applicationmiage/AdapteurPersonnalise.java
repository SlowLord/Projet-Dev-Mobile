package com.example.my_applicationmiage;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filterable;
import android.widget.TextView;
import android.widget.Filter;
import androidx.annotation.NonNull;
import java.util.ArrayList;

// Cette classe a été implémenter car je rencontrais des problèmes d'affichage lorsque le thème sombre est activé sur le téléphone.
// Les items étaient blanc sur un fond blanc donc on voyait pas trop bien
// J'ai donc recréer un Adapter personnalisé pour forcer la couleur des items en noir
// J'ai aussi du implémenter "Filterable" pour que le SearchView soit pris en charge correctement

public class AdapteurPersonnalise extends ArrayAdapter<String> implements Filterable {
    private final Context contexte;
    private final ArrayList<String> valeursOriginales; // Liste originale des valeurs
    private ArrayList<String> valeursFiltrees; // Liste filtrée des valeurs
    private final FiltrePersonnalise filtre;

    public AdapteurPersonnalise(Context contexte, ArrayList<String> valeurs) {
        super(contexte, R.layout.list_item, valeurs);
        this.contexte = contexte;
        this.valeursOriginales = new ArrayList<>(valeurs);
        this.valeursFiltrees = valeurs;
        this.filtre = new FiltrePersonnalise(); // Initialisation du filtre personnalisé
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        View vueLigne = convertView;
        if (vueLigne == null) {
            LayoutInflater inflater = (LayoutInflater) contexte.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            vueLigne = inflater.inflate(R.layout.list_item, parent, false);
        }

        TextView textView = vueLigne.findViewById(R.id.textViewItem);
        textView.setText(valeursFiltrees.get(position));

        // Définir la couleur du texte en noir
        textView.setTextColor(Color.BLACK);

        return vueLigne;
    }

    @Override
    public int getCount() {
        return valeursFiltrees.size(); // Retourne la taille de la liste filtrée
    }

    @Override
    public String getItem(int position) {
        return valeursFiltrees.get(position); // Retourne l'élément à la position donnée dans la liste filtrée
    }

    @NonNull
    @Override
    public Filter getFilter() {
        return filtre; // Retourne l'instance du filtre personnalisé
    }

    private class FiltrePersonnalise extends Filter {
        @Override
        protected FilterResults performFiltering(CharSequence contrainte) {
            FilterResults resultats = new FilterResults();
            ArrayList<String> listeFiltree = new ArrayList<>();

            if (contrainte == null || contrainte.length() == 0) {
                listeFiltree.addAll(valeursOriginales); // Si aucune contrainte de filtrage, utiliser la liste originale
            } else {
                String patternFiltrage = contrainte.toString().toLowerCase().trim();

                for (String item : valeursOriginales) {
                    if (item.toLowerCase().contains(patternFiltrage)) {
                        listeFiltree.add(item); // Ajouter les éléments correspondant à la contrainte de filtrage
                    }
                }
            }

            resultats.values = listeFiltree;
            resultats.count = listeFiltree.size();
            return resultats; // Retourne les résultats du filtrage
        }


        @SuppressWarnings("unchecked")
        @Override
        protected void publishResults(CharSequence contrainte, FilterResults resultats) {
            if (resultats.values instanceof ArrayList<?>) {
                valeursFiltrees = (ArrayList<String>) resultats.values; // Met à jour la liste filtrée avec les nouveaux résultats
            } else {
                // Optionnellement, gérer l'erreur, par exemple en utilisant une liste vide
                valeursFiltrees = new ArrayList<>();
            }
            notifyDataSetChanged(); // Notifie l'adaptateur que les données ont changé pour rafraîchir la vue
        }


    }
}
