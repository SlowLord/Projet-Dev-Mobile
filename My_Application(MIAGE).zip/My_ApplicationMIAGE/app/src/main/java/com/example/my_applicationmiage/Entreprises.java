package com.example.my_applicationmiage;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class Entreprises implements Parcelable {
    private String commentaire;
    private String nom;
    private String Secteur_Activite;
    private String numero;
    private String email_contact;
    private String nomPrenom_contact;
    private String Adresse;
    private String SiteWeb;
    private boolean Check;
    private String id_user;


    public Entreprises(String name, String activite, String numero, String email, String NomPrenom,String addr, String note, String web, String id, boolean chk){
        this.commentaire = note; // Note ajouté de l'utilisateur
        this.nom = name;
        this.Secteur_Activite = activite;
        this.numero = numero;
        this.email_contact = email;
        this.nomPrenom_contact = NomPrenom;
        this.Adresse = addr;
        this.SiteWeb = web;
        this.id_user = id;
        this.Check = chk;

    }

    protected Entreprises(Parcel e){
        commentaire = e.readString();
        nom = e.readString();
        Secteur_Activite = e.readString();
        numero = e.readString();
        email_contact = e.readString();
        nomPrenom_contact = e.readString();
        Adresse = e.readString();
        SiteWeb = e.readString();
        id_user = e.readString();
        Check = e.readByte() != 0;
    }

    public static final Creator<Entreprises> CREATOR = new Creator<Entreprises>() {
        @Override
        public Entreprises createFromParcel(Parcel e) {

            return new Entreprises(e);
        }

        @Override
        public Entreprises[] newArray(int size) {

            return new Entreprises[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeString(commentaire);
        dest.writeString(nom);
        dest.writeString(Secteur_Activite);
        dest.writeString(numero);
        dest.writeString(email_contact);
        dest.writeString(nomPrenom_contact);
        dest.writeString(Adresse);
        dest.writeString(SiteWeb);
        dest.writeString(id_user);
        dest.writeByte((byte) (Check ? 1 : 0));
    }


    public String getCommentaire(){
        return this.commentaire;
    }
    public void setCommentaire(String commentaire){
        this.commentaire = commentaire;
    }
    public String getNom(){
        return this.nom;
    }
    public void setNom(String nom){
        this.nom = nom;
    }
    public String getActivite(){
        return this.Secteur_Activite;
    }
    public void setActivite(String Activite){
        this.Secteur_Activite = Activite;
    }
    public String getNumero(){
        return this.numero;
    }
    public void setNumero(String numero){
        this.numero = numero;
    }
    public String getEmail(){
        return this.email_contact;
    }
    public void setEmail(String email){
        this.email_contact = email;
    }
    public String getPrenomContact(){return this.nomPrenom_contact;}
    public void setPrenomContact(String NomPrenom){this.nomPrenom_contact = NomPrenom;}
    public boolean getCheck(){
        return this.Check;
    }
    public void setCheck(boolean check){
        this.Check = check;
    }
    public String getAdresse(){
        return this.Adresse;
    }
    public void setAdresse(String adresse){
        this.Adresse = adresse;
    }
    public String getSiteWeb(){
        return this.SiteWeb;
    }
    public void setSiteWeb(String siteweb){
        this.SiteWeb = siteweb;
    }
    public String getId_user(){return this.id_user;}
    public void setId_user(String user){this.id_user = user;}

    
}
