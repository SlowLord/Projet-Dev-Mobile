package com.example.my_applicationmiage;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class InformationsEntreprise extends AppCompatActivity implements View.OnClickListener {
    public Entreprises ENTChoisi;
    public int positionENT = -1;
    public String User_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_informations_entreprise);

        // Régler la couleur de la barre d'état et la barre de navigation
        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.barreEtat));
        getWindow().setNavigationBarColor(ContextCompat.getColor(this, R.color.barreEtat)); // Forcer la couleur de la barre de navigation

        // Récupération de l'Id utilisateur
        Intent User = getIntent();
        User_id = User.getStringExtra("idUser");

        // Set des écouteurs sur les boutons Valider et Annuler
        Button boutonValider = findViewById(R.id.btnVALIDER);
        boutonValider.setOnClickListener(this);

        Button boutonRetour = findViewById(R.id.btnRETOUR);
        boutonRetour.setOnClickListener(this);

        // Récupération EditText et ImageView de l'entreprise
        EditText nomENT = findViewById(R.id.chmpENT);
        EditText secteurActiviteTextView = findViewById(R.id.chmpActivity);
        EditText numeroENT = findViewById(R.id.chmpTelephone);
        EditText emailContact = findViewById(R.id.chmpMailContact);
        EditText nomPrenomContact = findViewById(R.id.chmpContact);
        CheckBox EstContacte = findViewById(R.id.chxContacte);
        EditText notes = findViewById(R.id.chmpNotes);
        EditText Adresse = findViewById(R.id.chmpAdresse);
        EditText Siteweb = findViewById(R.id.chmpSiteWeb);


        // ------------------ CHANGEMENT DE COULEUR DES ICONES   --------------------------
        final ImageView icone_telephone = findViewById(R.id.icnTelephone);
        final ImageView icone_nomENT = findViewById(R.id.icn_NomENT);
        final ImageView icone_Activite = findViewById(R.id.icn_ActivityENT);
        final ImageView icone_Contact = findViewById(R.id.icn_Contact);
        final ImageView icone_SiteWeb = findViewById(R.id.icn_Web);
        final ImageView icone_notes = findViewById(R.id.icn_Notes);
        final ImageView icone_Adresse = findViewById(R.id.icn_Adresse);
        final ImageView icone_mail = findViewById(R.id.icn_Mail);


        // Pour le téléphone
        numeroENT.setOnFocusChangeListener((v, hasFocus) -> {
            if(hasFocus){icone_telephone.setImageResource(R.drawable.telephone_focus);}
            else{icone_telephone.setImageResource(R.drawable.telephone_default);}
        });

        // Pour le nom de l'entreprise
        nomENT.setOnFocusChangeListener((v, hasFocus) -> {
            if(hasFocus){icone_nomENT.setImageResource(R.drawable.ic_company_name_focus);}
            else{icone_nomENT.setImageResource(R.drawable.ic_company_name);}
        });

        // Pour l'Adresse
        Adresse.setOnFocusChangeListener((v, hasFocus) -> {
            if(hasFocus){icone_Adresse.setImageResource(R.drawable.ic_location_focus);}
            else{icone_Adresse.setImageResource(R.drawable.ic_location_default);}
        });

        // Pour l'Activité
        secteurActiviteTextView.setOnFocusChangeListener((v, hasFocus) -> {
            if(hasFocus){icone_Activite.setImageResource(R.drawable.ic_activity_focus);}
            else{icone_Activite.setImageResource(R.drawable.ic_activity_default);}
        });

        // Pour le Mail
        emailContact.setOnFocusChangeListener((v, hasFocus) -> {
            if(hasFocus){icone_mail.setImageResource(R.drawable.ic_mail_focus);}
            else{icone_mail.setImageResource(R.drawable.ic_mail_default);}
        });

        // Pour les Commentaires
        notes.setOnFocusChangeListener((v, hasFocus) -> {
            if(hasFocus){icone_notes.setImageResource(R.drawable.ic_notes_focus);}
            else{icone_notes.setImageResource(R.drawable.ic_notes_default);}
        });

        // Pour le Contact
        nomPrenomContact.setOnFocusChangeListener((v, hasFocus) -> {
            if(hasFocus){icone_Contact.setImageResource(R.drawable.ic_contact_focus);}
            else{icone_Contact.setImageResource(R.drawable.ic_contact_default);}
        });

        // Pour le Site Web
        Siteweb.setOnFocusChangeListener((v, hasFocus) -> {
            if(hasFocus){icone_SiteWeb.setImageResource(R.drawable.ic_web_focus);}
            else{icone_SiteWeb.setImageResource(R.drawable.ic_web_default);}
        });
        // ------------------ FIN CHANGEMENT DE COULEUR DES ICONES   -----------------------------------


        // --------------  On récupère le parcelable de l'objet Entreprises ----------------------------------
        Intent positionentreprise = getIntent();
        positionENT = positionentreprise.getIntExtra("positionENT",-1);


        Intent Company = getIntent();
        ENTChoisi = Company.getParcelableExtra("EntrepriseChoisi",Entreprises.class);
        if(ENTChoisi != null){
            // Affichage des attributs de l'entreprise dans les TextViews
            nomENT.setText(ENTChoisi.getNom());
            secteurActiviteTextView.setText(ENTChoisi.getActivite());
            numeroENT.setText(ENTChoisi.getNumero());
            emailContact.setText(ENTChoisi.getEmail());
            nomPrenomContact.setText(ENTChoisi.getPrenomContact());
            EstContacte.setChecked(ENTChoisi.getCheck());
            notes.setText(ENTChoisi.getCommentaire());
            Adresse.setText(ENTChoisi.getAdresse());
            Siteweb.setText(ENTChoisi.getSiteWeb());
        }
        // --------------  FIN récupération du parcelable de l'objet Entreprises ----------------------------------

    }

    @Override
    public void onClick(View v) {
        // Gestion du bouton Valider
        if(v.getId() == R.id.btnVALIDER){
            EditText nomENT = findViewById(R.id.chmpENT);
            EditText secteurActiviteTextView = findViewById(R.id.chmpActivity);
            EditText numeroENT = findViewById(R.id.chmpTelephone);
            EditText emailContact = findViewById(R.id.chmpMailContact);
            EditText nomPrenomContact = findViewById(R.id.chmpContact);
            CheckBox EstContacte = findViewById(R.id.chxContacte);
            EditText notes = findViewById(R.id.chmpNotes);
            EditText Adresse = findViewById(R.id.chmpAdresse);
            EditText Siteweb = findViewById(R.id.chmpSiteWeb);


            if (ENTChoisi != null) {
                // Mise à jour des informations(attribut) de l'objet ENTChoisi
                ENTChoisi.setNom(nomENT.getText().toString());
                ENTChoisi.setActivite(secteurActiviteTextView.getText().toString());
                ENTChoisi.setNumero(numeroENT.getText().toString());
                ENTChoisi.setEmail(emailContact.getText().toString());
                ENTChoisi.setPrenomContact(nomPrenomContact.getText().toString());
                ENTChoisi.setCheck(EstContacte.isChecked());
                ENTChoisi.setCommentaire(notes.getText().toString());
                ENTChoisi.setAdresse(Adresse.getText().toString());
                ENTChoisi.setSiteWeb(Siteweb.getText().toString());

            }
            else{
                //Création d'une nouvelle entreprise
                ENTChoisi = new Entreprises(nomENT.getText().toString().trim(),
                        secteurActiviteTextView.getText().toString().trim(),
                        numeroENT.getText().toString().trim(),
                        emailContact.getText().toString().trim(),
                        nomPrenomContact.getText().toString().trim(),
                        Adresse.getText().toString().trim(),
                        notes.getText().toString().trim(),
                        Siteweb.getText().toString().trim(),
                        User_id,
                        EstContacte.isChecked());

            }
            // Renvoyer l'objet mis à jour dans l'activité précédente
            Intent updateCompany = new Intent();
            updateCompany.putExtra("UpdatedEntreprise", ENTChoisi);
            updateCompany.putExtra("MAJpositionENT",positionENT);
            setResult(RESULT_OK, updateCompany);
            finish();
        }

        // Gestion du bouton Retour
        if(v.getId() == R.id.btnRETOUR){
            finish();
        }
    }
}