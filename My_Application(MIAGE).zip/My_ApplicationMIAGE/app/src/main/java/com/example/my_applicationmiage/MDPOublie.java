package com.example.my_applicationmiage;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;


public class MDPOublie extends AppCompatActivity implements View.OnClickListener{

    ImageButton imageBtnShowPassword;
    EditText editTextPassword;
    boolean motdepasseVisible = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_mdpoublie);
        Button RESET = findViewById(R.id.btnRESET);
        RESET.setOnClickListener(this);

        // Régler la couleur de la barre d'état et la barre de navigation
        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.barreEtat));
        getWindow().setNavigationBarColor(ContextCompat.getColor(this, R.color.barreEtat));

        imageBtnShowPassword = findViewById(R.id.icBtnPsswrd);
        imageBtnShowPassword.setOnClickListener(this);
        editTextPassword = findViewById(R.id.chmpMDPreset);
    }

    @Override
    public void onClick(View v) {
        EditText LOGIN= findViewById(R.id.chmpemailRESET);
        EditText MDP = findViewById(R.id.chmpMDPreset);
        String login = LOGIN.getText().toString().trim();
        String password = MDP.getText().toString().trim();



        // Si il clique sur Réinitialiser
        if(v.getId() == R.id.btnRESET){
            if(!login.isEmpty() && !password.isEmpty()){
                Intent newlogin = new Intent();
                newlogin.putExtra("email",login);
                newlogin.putExtra("NewMDP",password);
                setResult(2, newlogin);
                Log.i("Myapp","Mot de passe réinitialisé avec succès");
                finish();
            }
            else{Toast.makeText(MDPOublie.this,"Email ou Mot de passe incorrect !", Toast.LENGTH_SHORT).show();}
        }

        // Si il clique sur l'icone pour afficher ou masquer le mot de passe
        if(v.getId() == R.id.icBtnPsswrd){
            PasswordSwitchMode();
        }
    }

    //  Afficher ou masquer le mot de passe ainsi que l'icone associé
    private void PasswordSwitchMode(){
        if(motdepasseVisible){
            // Si le mot de passe est visible, le masquer
            editTextPassword.setInputType(InputType.TYPE_CLASS_TEXT |InputType.TYPE_TEXT_VARIATION_PASSWORD);
            motdepasseVisible = false;
            imageBtnShowPassword.setImageResource(R.drawable.ic_visibility_off);
        }
        else{
            // Si le mot de passe est masqué, le rendre visible
            editTextPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            motdepasseVisible = true;
            imageBtnShowPassword.setImageResource(R.drawable.ic_visibility_on);
        }
        // Pour déplacer le curseur à la fin du texte après le changement de type d'entrée
        editTextPassword.setSelection(editTextPassword.getText().length());

    }

}