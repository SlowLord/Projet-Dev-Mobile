package com.example.my_applicationmiage;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.UnderlineSpan;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.content.Intent;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import org.w3c.dom.Text;

import java.io.FileWriter;
import java.io.IOException;
import java.net.PasswordAuthentication;
import java.util.ArrayList;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    ArrayList<Utilisateurs> ListeUtilisateurs = new ArrayList<>();
    ArrayList<String> NomsUtilisateurs = new ArrayList<>();
    ArrayList<String> EMAIL_Utilisateur = new ArrayList<>();
    public ActivityResultLauncher<Intent> activityResultLauncher;
    ImageButton imageButtonShowPassword;
    EditText editTextPassword;
    boolean motdepasseVisible = false;

    String emailREST;
    String mdpRESET;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        Persistance_Donnees.Vider_Fichiers_Utilisateurs(this);
//        Log.v("Myapp","Utilisateurs supprimés" + ListeUtilisateurs.toString());
//        Log.v("Myapp","emails supprimés" + EMAIL_Utilisateur.toString());
//        Log.v("Myapp","pseudo supprimés" + NomsUtilisateurs.toString());


        // Régler la couleur de la barre d'état et la barre de navigation
        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.barreEtat));
        getWindow().setNavigationBarColor(ContextCompat.getColor(this, R.color.barreEtat)); // Forcer la couleur de la barre de navigation

        // Pour souligner le texte du texteView
        TextView mdpoublie = findViewById(R.id.txtmdpoublie);
        String texte = getString(R.string.textMDPoubli);
        SpannableString spannableString = new SpannableString(texte);
        spannableString.setSpan(new UnderlineSpan(),0,spannableString.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        mdpoublie.setText(spannableString);
        mdpoublie.setOnClickListener(this);

        Button boutontValider = findViewById(R.id.btValider);
        boutontValider.setOnClickListener(this);

        Button boutontAnnuler = findViewById(R.id.btAnnuler);
        boutontAnnuler.setOnClickListener(this);

        Button boutonInscription = findViewById(R.id.btnSignIn);
        boutonInscription.setOnClickListener(this);

        ImageButton exit = findViewById(R.id.exit_icn);
        exit.setOnClickListener(this);

        // Ecouteur pour le champ de saisi et l'icone du mot de passe
        editTextPassword = findViewById(R.id.chpMdp);
        imageButtonShowPassword = findViewById(R.id.imageButtonShowPassword);
        imageButtonShowPassword.setOnClickListener(this);


        // Pour charger
        ListeUtilisateurs = Persistance_Donnees.Charger_Utilisateurs(this);
        NomsUtilisateurs = Persistance_Donnees.Charger_NomsUtilisateurs(this);
        EMAIL_Utilisateur = Persistance_Donnees.Charger_EMAIL_Utilisateur(this);
        Log.v("MyApp","1Votre liste de pseudo: "+NomsUtilisateurs.toString());
        Log.v("MyApp","1Votre liste de mail: "+EMAIL_Utilisateur.toString());
        Log.v("MyApp","1Votre liste Utilisateur: "+ListeUtilisateurs.toString());


        activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    int codeResult = result.getResultCode();
                    Intent data = result.getData();
                    if(codeResult == 1){ // Données provenant de l'activité pour créer un compte
                        if(data != null){
                            Utilisateurs newUser = data.getParcelableExtra("NewUtilisateur",Utilisateurs.class);
                            if(newUser != null){
                                if(!NomsUtilisateurs.contains(newUser.getPseudonyme()) && !EMAIL_Utilisateur.contains(newUser.getLogin())){
                                    NomsUtilisateurs.add(newUser.getPseudonyme());
                                    EMAIL_Utilisateur.add(newUser.getLogin());
                                    ListeUtilisateurs.add(newUser);
                                    Toast.makeText(MainActivity.this, "Inscription réussi !", Toast.LENGTH_SHORT).show();
                                    // DEBUG TEST --> Affichage des listes de pseudo et email
                                    Log.v("MyApp","2Votre liste de pseudo: "+NomsUtilisateurs.toString());
                                    Log.v("MyApp","2 liste de mail: "+EMAIL_Utilisateur.toString());
                                    Log.v("MyApp","2Votre liste Utilisateur: "+ListeUtilisateurs.toString());
                                    // Sauvegarde des utilisateurs
                                    //Persistance_Donnees.Sauvegarde_Utilisateurs(ListeUtilisateurs, NomsUtilisateurs, EMAIL_Utilisateur, this);


                                }
                                else{Toast.makeText(MainActivity.this, "Il existe un compte avec ces informaitons !", Toast.LENGTH_SHORT).show();
                                    // DEBUG TEST --> Affichage des listes de pseudo et email
                                    Log.v("MyApp","3Votre liste de pseudo: "+NomsUtilisateurs.toString());
                                    Log.v("MyApp","3Votre liste de mail: "+EMAIL_Utilisateur.toString());
                                    Log.v("MyApp","3Votre liste Utilisateur: "+ListeUtilisateurs.toString());
                                }
                            }
                            else{Log.v("MyApp","Objet utilisateur non recu: ");
                            }
                        }
                    } else if (codeResult == 2){ // Données provenant de l'activité pour réinitialiser un mot de passe
                        if(data != null){
                            emailREST = data.getStringExtra("email");
                            mdpRESET = data.getStringExtra("NewMDP");
                            if(emailREST != null && mdpRESET !=null){
                                RESET_MotDePasse(emailREST,mdpRESET);
                                // Sauvegarde des utilisateurs
                                //Persistance_Donnees.Sauvegarde_Utilisateurs(ListeUtilisateurs, NomsUtilisateurs, EMAIL_Utilisateur, this);

                            }
                            else{Log.v("MyApp","Nouveau ID non recu: ");
                            }
                        }
                    }
                }
        );

    }

    public void onStop(){
        super.onStop();
        Log.i("MyApp", "Application 1 stop");
    }
    public void onRestart(){
        super.onRestart();
        Log.i("MyApp", "Application revient au premier plan");
    }

    public void onClick(View v){

        EditText champLog = findViewById(R.id.chpLogin);
        EditText champmdp = findViewById(R.id.chpMdp);

        // Si il clique sur connexion
        if(v.getId() == R.id.btValider){
            connnexion_valide();
        }

        // Si il clique sur l'icone pour afficher ou masquer le mot de passe
        if(v.getId() == R.id.imageButtonShowPassword){
            PasswordSwitchMode();
        }

        // Si il clique sur le bouton Annuler
        if(v.getId() == R.id.btAnnuler){
            champLog.setText("");
            champmdp.setText("");
            Log.i("Myapp","1 click sur le bouton Annuler");

        }

        // Si il clique sur Mot de passe oublié
        if (v.getId() == R.id.txtmdpoublie){
            Intent resetmdp = new Intent(this, MDPOublie.class);
            activityResultLauncher.launch(resetmdp);
            Log.i("Myapp","Un clique sur mot de passe oublié !");
        }


        // Si il clique sur le bouton Créer un compte
        if(v.getId() == R.id.btnSignIn){
            Intent inscription = new Intent(this,ActivitySignIn.class);
            activityResultLauncher.launch(inscription);
            Log.i("Myapp","1 click sur le bouton Inscription");
        }

        // Si il clique sur l'icone en haut a droite pour sortir de l'application
        if(v.getId() == R.id.exit_icn){
            Log.i("Myapp","1 click sur le bouton Exit");
            Quitter();
        }
    }


    // Méthode qui regarde si les identifiants rentrer par l'utilisateur sont correct
    public void connnexion_valide(){
        EditText champLog = findViewById(R.id.chpLogin);
        EditText champmdp = findViewById(R.id.chpMdp);
        String logintext = champLog.getText().toString().trim();
        String mdptext = champmdp.getText().toString().trim();
        if(!logintext.isEmpty() && !mdptext.isEmpty()) {
            if(EMAIL_Utilisateur.contains(logintext)){
                for(Utilisateurs utilisateur: ListeUtilisateurs){
                    if(utilisateur.getLogin().equals(logintext) && utilisateur.getPassword().equals(mdptext)){
                        Intent it1 = new Intent(this, MainActivity2.class);
                        it1.putExtra("login", utilisateur.getPseudonyme());
                        startActivity(it1);
                        Log.i("Myapp", "Bonjour " + utilisateur.getPseudonyme() + " (APP1)");
                        return;
                    }

                }
                Toast.makeText(MainActivity.this, "Login ou mot de passe incorrect !", Toast.LENGTH_SHORT).show();

            }else{ Toast.makeText(MainActivity.this, "Login ou mot de passe incorrect !", Toast.LENGTH_SHORT).show();}


        }
        else{
            Toast.makeText(MainActivity.this, "Login ou mot de passe incorrect !", Toast.LENGTH_SHORT).show();
        }
    }

    // Méthode qui permet de réinitialiser le mot de passe
    public void RESET_MotDePasse(String email, String mdp){
        for(Utilisateurs utilisateur : ListeUtilisateurs){
            if(utilisateur.getLogin().equals(email)){
                utilisateur.setPassword(mdp);
                Toast.makeText(MainActivity.this, "Mot de passe réinitialisé avec succès !", Toast.LENGTH_SHORT).show();
                break;
            }
        }
    }




    // AlertDialog pour vérifier la déconnexion(sortir de l'application)
    private void Quitter(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("QUITTER !")
                .setMessage("Êtes-vous sûr de vouloir quitter ?")
                .setPositiveButton("QUITTER", (dialog, id) -> {
                    finishAffinity();
                    System.exit(0);
                })
                .setNegativeButton("ANNULER", (dialog, id) -> dialog.dismiss());
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    //  Afficher ou masquer le mot de passe ainsi que l'icone associé
    private void PasswordSwitchMode(){
        if(motdepasseVisible){
            // Si le mot de passe est visible, le masquer
            editTextPassword.setInputType(InputType.TYPE_CLASS_TEXT |InputType.TYPE_TEXT_VARIATION_PASSWORD);
            motdepasseVisible = false;
            imageButtonShowPassword.setImageResource(R.drawable.ic_visibility_off);
        }
        else{
            // Si le mot de passe est masqué, le rendre visible
            editTextPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            motdepasseVisible = true;
            imageButtonShowPassword.setImageResource(R.drawable.ic_visibility_on);
        }
        // Pour déplacer le curseur à la fin du texte après le changement de type d'entrée
        editTextPassword.setSelection(editTextPassword.getText().length());

    }


}