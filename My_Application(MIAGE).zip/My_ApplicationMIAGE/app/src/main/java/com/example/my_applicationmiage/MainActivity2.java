package com.example.my_applicationmiage;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.View;
import android.util.Log;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CompoundButton;
import android.view.MotionEvent;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.SearchView;
import android.widget.TextView;
import android.content.Intent;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.activity.EdgeToEdge;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import android.graphics.Color;



public class MainActivity2 extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener, View.OnClickListener, AdapterView.OnItemClickListener, AdapterView.OnItemLongClickListener {

    public ArrayList<Entreprises> ListeEntreprises = new ArrayList<>();
    public AdapteurPersonnalise matching;
    public String id_user;

    private GestureDetector gestureDetector;
    public ActivityResultLauncher<Intent> activityResultLauncher;


    @SuppressLint({"SetTextI18n", "ClickableViewAccessibility"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);

        // Régler la couleur de la barre d'état et la barre de navigation
        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.barreEtat));
        getWindow().setNavigationBarColor(ContextCompat.getColor(this, R.color.barreEtat)); // Forcer la couleur de la barre de navigation

        // Charger les données enregistrées en JSON
        ListeEntreprises = Persistance_Donnees.Charger_Entreprises(this);
        Log.i("Myapp", "(APP2)ListeEntreprises: "+ ListeEntreprises);
       // mainNomEntreprises = Persistance_Donnees.Charger_Noms_Entreprises(this);

        //-------------------------------------------------------------
        Intent int1 = getIntent();
        id_user = int1.getStringExtra("login");
        TextView messagelog = findViewById(R.id.TextAct2);
        messagelog.setText("Bonjour "+id_user);
        Toast.makeText(this,"Bonjour "+ id_user,Toast.LENGTH_SHORT).show();

        Button retour = findViewById(R.id.RetourBTN);
        retour.setOnClickListener(this);

        Button ajouter = findViewById(R.id.Add);
        ajouter.setOnClickListener(this);

        //Initialisation et ecoute de l'icone de retour a l'activité 1
        ImageButton ic_retour = findViewById(R.id.icRetour);
        ic_retour.setOnClickListener(this);

        // Initialisation du Détecteur de mouvement
        gestureDetector = new GestureDetector(this, new SwipeGestureDetector());

        // Ecouteurs d'événements pour les RadioButtons

        RadioButton radioButtonToutes = findViewById(R.id.rdogrpToutes);
        radioButtonToutes.setOnCheckedChangeListener(this);
        radioButtonToutes.setChecked(true);

        RadioButton radioButtonContactees = findViewById(R.id.rdogrpContacte);
        radioButtonContactees.setOnCheckedChangeListener(this);

        RadioButton radioButtonNonContactees = findViewById(R.id.rdogrpNonContacte);
        radioButtonNonContactees.setOnCheckedChangeListener(this);

        // Association de la listView et son Adapter
        ListView maliste = findViewById(R.id.mylist);
        maliste.setOnItemClickListener(this);
        maliste.setOnItemLongClickListener(this);

        ArrayList<String> liste = liste_Global_User(id_user);
        matching = new AdapteurPersonnalise(this, liste);
        maliste.setAdapter(matching);


        // Ajouter le OnTouchListener qui va me permettre de gérer le swipe pour changer d'option
        maliste.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return gestureDetector.onTouchEvent(event);
            }
        });

        //-------------------  PARRAMETRAGE SEARCHVIEW -------------------------------------
        SearchView mSearchView = findViewById(R.id.mysearchview);

        // Récupérer le champ de texte du SearchView
        @SuppressLint("DiscouragedApi") int id = mSearchView.getContext().getResources().getIdentifier("android:id/search_src_text", null, null);
        EditText searchEditText = mSearchView.findViewById(id);
        // Définir la couleur du texte en noir
        searchEditText.setTextColor(Color.BLACK);


        //Méthode pour la SearchView qui permet d'effectuer un recherche spécifique
        mSearchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                MainActivity2.this.matching.getFilter().filter(s);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                MainActivity2.this.matching.getFilter().filter(s);
                return false;
            }
        });
        // ---------------------------- FIN PARRAMETRAGE SEARCHVIEW ------------------------------

        // -------------------------------- Récupération de l'entreprise créé ou celle mise à jour --------------------
        //Initialisation de ActivityResultLauncher qui me permet de récupérer le résultat d'une autre activité
        activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) { // Si tout s'est bien passer
                        Intent Int_entreprise = result.getData();
                        if (Int_entreprise != null) {
                            int positionENT = Int_entreprise.getIntExtra("MAJpositionENT", -1);

                            Entreprises updatedEntreprise = Int_entreprise.getParcelableExtra("UpdatedEntreprise", Entreprises.class);
                            if (updatedEntreprise != null) {
                                if(positionENT == -1) { // Si positionENT == -1, cela veut dire qu'on ajoute une nouvelle entreprise
                                    if (!updatedEntreprise.getNom().isEmpty()) {
                                        // L'entreprise est nouvelle, l'ajouter aux listes
                                        if(!Ajout_EntrepriseExistant(updatedEntreprise.getNom(),id_user)) {
                                            ListeEntreprises.add(updatedEntreprise);
                                            MAJListView(); // On rafraichit l'adapter
                                            Toast.makeText(MainActivity2.this, "Entreprise ajouté", Toast.LENGTH_SHORT).show();
                                            Log.v("Myapp", "Nouvelle ENT ajouté");
                                        }
                                        else{Toast.makeText(MainActivity2.this, "Entreprise déjà ajoutée !", Toast.LENGTH_SHORT).show();}
                                    }
                                    else{Toast.makeText(MainActivity2.this, "Ajout impossible !", Toast.LENGTH_SHORT).show();}
                                }
                                else { // Sinon on récupère la position passé dans l'Intent pour mettre à jour l'entreprise
                                    if(!updatedEntreprise.getNom().isEmpty()){
                                        // Sinon, mettre à jour l'entreprise existante a la position récupérée
                                        MAJEntreprise(updatedEntreprise,positionENT);
                                        Log.v("MYAPP", "Voici la liste Entreprises des entreprises" + ListeEntreprises.toString());
                                    }
                                    else{Toast.makeText(MainActivity2.this, "Modification impossible !", Toast.LENGTH_SHORT).show();}


                                }
                                Persistance_Donnees.Sauvegarde_Donnees(ListeEntreprises,this);
                            }
                        }
                    }
                }
        );
        // -------------------------------- FIN Récupération de l'entreprise créé ainsi que celle mise à jour --------------------

    }


    // ---------------------Classe interne pour détecter les gestes de balayage-------------------------------
    private class SwipeGestureDetector extends GestureDetector.SimpleOnGestureListener {
        private static final int SWIPE_THRESHOLD = 200; // Ajustez cette valeur selon vos besoins
        private static final int SWIPE_VELOCITY_THRESHOLD = 200; // Ajustez cette valeur selon vos besoins

        @Override
        public boolean onFling(MotionEvent e1, @NonNull MotionEvent e2, float velocityX, float velocityY) {
            try {
                float diffY = e2.getY() - e1.getY();
                float diffX = e2.getX() - e1.getX();
                if (Math.abs(diffX) > Math.abs(diffY)) {
                    if (Math.abs(diffX) > SWIPE_THRESHOLD && Math.abs(velocityX) > SWIPE_VELOCITY_THRESHOLD) {
                        if (diffX > 0) {
                            onSwipeRight();
                        } else {
                            onSwipeLeft();
                        }
                        return true;
                    }
                }
            } catch (Exception exception) {
                Log.e("MYAPP", "Erreur swipe", exception);
            }
            return false;
        }

    }

    //Changer d'option sur un swipe à droite
    private void onSwipeRight() {
        RadioButton radioButtonToutes = findViewById(R.id.rdogrpToutes);
        RadioButton radioButtonContactees = findViewById(R.id.rdogrpContacte);
        RadioButton radioButtonNonContactees = findViewById(R.id.rdogrpNonContacte);

        if (radioButtonContactees.isChecked()) {
            radioButtonToutes.setChecked(true);
        } else if (radioButtonNonContactees.isChecked()) {
            radioButtonContactees.setChecked(true);
        } else {
            radioButtonNonContactees.setChecked(true);
        }
    }
    
    
    //Changer d'option sur un swipeà gauche
    private void onSwipeLeft() {
        RadioButton radioButtonToutes = findViewById(R.id.rdogrpToutes);
        RadioButton radioButtonContactees = findViewById(R.id.rdogrpContacte);
        RadioButton radioButtonNonContactees = findViewById(R.id.rdogrpNonContacte);

        if (radioButtonToutes.isChecked()) {
            radioButtonContactees.setChecked(true);
        } else if (radioButtonContactees.isChecked()) {
            radioButtonNonContactees.setChecked(true);
        } else {
            radioButtonToutes.setChecked(true);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (gestureDetector.onTouchEvent(event)) {
            return true;
        }
        return super.onTouchEvent(event);
    }
    // --------------------- FIN Classe interne pour détecter les gestes de balayage-------------------------------


    // Foncttion qui regarde si le nom d'une entreprise existe déjà lors sa création par l'utilisateur
    public boolean Ajout_EntrepriseExistant(String nom, String user){
        if(ListeEntreprises !=null) {
            for (Entreprises entreprises : ListeEntreprises) {
                if (entreprises.getNom().equals(nom) && entreprises.getId_user().equals(user)) {
                    return true; // L'utilisateur à déjà créé cette entreprise
                }
            }
        }
        return false;

    }

    // Fonction qui regarde si le nom d'une entreprise mise a jour existe deja
    // Cela évite de modifier le nom d'un entreprise en une déjà créé
    private boolean Modification_EntrepriseExistant(String nouveauNom, int positionActuelle) {
        for (int i = 0; i < ListeEntreprises.size(); i++) {
            if (i != positionActuelle && ListeEntreprises.get(i).getNom().equals(nouveauNom) && ListeEntreprises.get(i).getId_user().equals(id_user)) {
                Toast.makeText(this, "Modification impossible. Entreprise déjà ajouté !",Toast.LENGTH_LONG).show();
                return true; // Le nom existe déjà pour une autre entreprise
            }
        }
        return false; // Le nom n'existe pas pour une autre entreprise
    }



    // Mise à jour de l'entreprise en fonction de sa position
    private void MAJEntreprise(Entreprises updatedEntreprise, int position) {

        RadioButton rdoToutes = findViewById(R.id.rdogrpToutes);
        RadioButton rdoContacte = findViewById(R.id.rdogrpContacte);
        RadioButton rdoNonContacte = findViewById(R.id.rdogrpNonContacte);

        Entreprises Ancien_entreprise = ListeEntreprises.get(position);
        String nouveauNom = updatedEntreprise.getNom();

        // Vérifier si le nouveau nom est déjà utilisé pour une autre entreprise
        if (!Ancien_entreprise.getNom().equals(nouveauNom) && Modification_EntrepriseExistant(nouveauNom, position)) {
            Toast.makeText(MainActivity2.this, "Modification impossible !", Toast.LENGTH_SHORT).show();
            return;
        }
        else {
            Ancien_entreprise.setNom(updatedEntreprise.getNom());
            Ancien_entreprise.setAdresse(updatedEntreprise.getAdresse());
            Ancien_entreprise.setActivite(updatedEntreprise.getActivite());
            Ancien_entreprise.setNumero(updatedEntreprise.getNumero());
            Ancien_entreprise.setEmail(updatedEntreprise.getEmail());
            Ancien_entreprise.setCommentaire(updatedEntreprise.getCommentaire());
            Ancien_entreprise.setCheck(updatedEntreprise.getCheck());
            Ancien_entreprise.setSiteWeb(updatedEntreprise.getSiteWeb());
            Ancien_entreprise.setPrenomContact(updatedEntreprise.getPrenomContact());

            // Mettre à jour la ListView en fonction du RadioButton sélectionné
            if (rdoToutes.isChecked()) {
                AffhichageListeEntrepriseGlobal(id_user);
            } else if (rdoContacte.isChecked()) {
                AffichageListeEntrepriseContacteOuNon(true, id_user);
            } else if (rdoNonContacte.isChecked()) {
                AffichageListeEntrepriseContacteOuNon(false, id_user);
            }
            Toast.makeText(MainActivity2.this, "Entreprise mise à jour", Toast.LENGTH_SHORT).show();

        }
    }



    public void onClick(View v){

        // Si il clique sur Ajouter
        if (v.getId() == R.id.Add) {
            Log.v("Myapp", "1 clic sur le bouton AJOUTER ");
            Intent AjoutEntreprise = new Intent(this, InformationsEntreprise.class);
            AjoutEntreprise.putExtra("idUser",id_user);
            activityResultLauncher.launch(AjoutEntreprise);
        }

        // Si il clique sur l'icone retour en haut a gauche (petite flèche) pour se déconnecter
        else if(v.getId() == R.id.icRetour){
            Log.i("Myapp","1 click sur le bouton retour!");
            Se_Deconnecter();
        }
    }


    // AlertDialog pour vérifier la déconnexion
    private void Se_Deconnecter(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("DÉCONNEXION !")
                .setMessage("Êtes-vous sûr de vouloir vous déconnecter ?")
                .setPositiveButton("DÉCONNEXION", (dialog, id) -> {
                    Intent retourAct1 = new Intent(this, MainActivity.class);
                    startActivity(retourAct1);
                })
                .setNegativeButton("ANNULER", (dialog, id) -> dialog.dismiss());
        AlertDialog dialog = builder.create();
        dialog.show();
    }



    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

         Entreprises ENTChoisi = null;

         RadioButton rdoToutes = findViewById(R.id.rdogrpToutes);
         RadioButton rdoContacte = findViewById(R.id.rdogrpContacte);
         RadioButton rdoNonContacte = findViewById(R.id.rdogrpNonContacte);

         // Récupérer le texte de l'élément cliqué dans la ListView filtrée
         String NomEntSelec = matching.getItem(position);

         int positionENT= -1;
         // Trouver l'entreprise correspondante en fonction du nom et de l'utilisateur auquel il appartient
         if (rdoToutes.isChecked() || rdoContacte.isChecked() || rdoNonContacte.isChecked()) {
             for (Entreprises entreprise : ListeEntreprises) {
                if (entreprise.getNom().equals(NomEntSelec) && entreprise.getId_user().equals(id_user)) {
                    ENTChoisi = entreprise;
                    positionENT = ListeEntreprises.indexOf(entreprise);
                    break;
                }
            }
         }

         // Si l'entreprise a été trouvé on le basule dans l'autre activité
         if (ENTChoisi != null) {
             Intent Companydetails = new Intent(this, InformationsEntreprise.class);
             Companydetails.putExtra("EntrepriseChoisi", ENTChoisi);
             Companydetails.putExtra("positionENT",positionENT);
             activityResultLauncher.launch(Companydetails);
         }


    }



    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
        //Appel de la méthode 'PopUpEntSupprimer' pour supprimer l'entreprise
        PopUpEntSupprimer(position);
        return true;

    }

    // Méthode pour supprimer une entreprise
    private void PopUpEntSupprimer(int position) {
        //---------------------------------------------------------------------------------------------------------
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Confirmation de suppression")
            .setMessage("Êtes-vous sûr de vouloir supprimer cette entreprise ?")
            .setPositiveButton("SUPPRIMER", (dialog, id) -> {
                String NomEntSelec = matching.getItem(position);

                // Recherche de l'entreprise correspondante dans ListeEntreprises
                Entreprises entrepriseASupprimer = null;
                for (Entreprises entreprise : ListeEntreprises) {
                    if (entreprise.getNom().equals(NomEntSelec) && entreprise.getId_user().equals(id_user)) {
                        entrepriseASupprimer = entreprise;
                        break;
                    }
                }

                // Vérifie si l'entreprise a été trouver
                if (entrepriseASupprimer != null) {
                    // Supprimer l'entreprise des différentes listes
                    ListeEntreprises.remove(entrepriseASupprimer);

                    Persistance_Donnees.Sauvegarde_Donnees(ListeEntreprises,this);
                    // Mettre à jour la ListView en fonction de l'option sélectionnée
                    MAJListView();

                    Toast.makeText(MainActivity2.this, "Entreprise supprimée", Toast.LENGTH_SHORT).show();
                } else {
                    // Si l'entreprise n'est pas trouvée, afficher un message d'erreur
                    Toast.makeText(MainActivity2.this, "Entreprise non trouvée", Toast.LENGTH_SHORT).show();
                }
            })
            .setNegativeButton("ANNULER", (dialog, id) -> dialog.dismiss());
        AlertDialog dialog = builder.create();
        dialog.show();

    }
    

    // Méthode qui permet de raffraichier l'adapter et les éléments de la listeView en fonction de l'option sélectionné
    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        TextView lstENT = findViewById(R.id.listeENT);
        if (isChecked) {
            if (buttonView == findViewById(R.id.rdogrpToutes) && buttonView.isChecked()) {
                AffhichageListeEntrepriseGlobal(id_user);
                lstENT.setText(R.string.lstentreprise);
                Log.v("Myapp", "Vous avez cliqué sur l'option TOUTE");



            } else if (buttonView == findViewById(R.id.rdogrpContacte) && buttonView.isChecked()) {
                lstENT.setText(R.string.lstentrepriseContacte);
                AffichageListeEntrepriseContacteOuNon(true, id_user);
                Log.v("Myapp", "Vous avez cliqué sur l'option CONTACTE");


            } else if (buttonView == findViewById(R.id.rdogrpNonContacte) && buttonView.isChecked()) {
                lstENT.setText(R.string.lstentrepriseNonContacte);
                AffichageListeEntrepriseContacteOuNon(false, id_user);
                Log.v("Myapp", "Vous avez cliqué sur l'option NonContacte");

            }
        }
    }

    // Méthode qui permet de rafraichir l'adapter
    public void MAJListView(){
        RadioButton rdoToutes = findViewById(R.id.rdogrpToutes);
        RadioButton rdoContacte = findViewById(R.id.rdogrpContacte);
        RadioButton rdoNonContacte = findViewById(R.id.rdogrpNonContacte);

        // Mettre à jour la ListView en fonction du RadioButton sélectionné
        if (rdoToutes.isChecked()) {
            Log.v("Myapp", "Vous êtes dans l'option TOUTES 5");
            //MAJListView(mainNomEntreprises);
            AffhichageListeEntrepriseGlobal(id_user);
        } else if (rdoContacte.isChecked()) {
            Log.v("Myapp", "Vous êtes dans l'option CONTACTE 5");
            AffichageListeEntrepriseContacteOuNon(true, id_user);
        } else if (rdoNonContacte.isChecked()) {
            Log.v("Myapp", "Vous êtes dans l'option NonCONTACTE 5");
            AffichageListeEntrepriseContacteOuNon(false, id_user);
        }
    }

    // Méthode qui permet de rafraichir l'adpter si on est dans l'option Toutes
    public void AffhichageListeEntrepriseGlobal(String user){
        ArrayList<String> maliste = new ArrayList<>();
        if(!ListeEntreprises.isEmpty()) {
            Log.i("Myapp","AfficheGlobal ListeEntreprises: "+ListeEntreprises.toString());
            for (Entreprises entreprise : ListeEntreprises) {
                Log.i("Myapp","IdUserENT: "+ entreprise.getId_user());
                if (entreprise.getId_user().equals(user)) {
                    maliste.add(entreprise.getNom());
                }
            }
            //matching = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, maliste);
            matching = new AdapteurPersonnalise(this, maliste);
            ListView Maliste = findViewById(R.id.mylist);
            Maliste.setAdapter(matching);
            matching.notifyDataSetChanged();

        }
    }

    // Méthode qui renvoie une liste String pour l'adapter lors de la première initialisation dans le onCreate, si aucune entreprise n'a encore été ajouter
    public ArrayList<String> liste_Global_User(String user){
        ArrayList<String> ENTUser = new ArrayList<>();
        for(Entreprises entreprise : ListeEntreprises){
            if(entreprise.getId_user().equals(user)){
                ENTUser.add(entreprise.getNom());
            }
        }
        return ENTUser;
    }


    // Méthode qui permet de rafraichir l'adpter si on est dans l'option Contactés ou Non Contactés
    public void AffichageListeEntrepriseContacteOuNon(boolean check, String user){
        ArrayList<String> maliste = new ArrayList<>();
        for(Entreprises entreprise: ListeEntreprises){
            if(entreprise.getCheck() == check && entreprise.getId_user().equals(user)){
                maliste.add(entreprise.getNom());
            }
        }
        //matching = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, maliste);
        matching = new AdapteurPersonnalise(this, maliste);
        ListView Maliste = findViewById(R.id.mylist);
        Maliste.setAdapter(matching);
        matching.notifyDataSetChanged();

    }

}
