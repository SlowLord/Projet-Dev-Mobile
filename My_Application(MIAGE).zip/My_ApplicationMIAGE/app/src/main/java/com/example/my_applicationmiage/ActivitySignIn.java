package com.example.my_applicationmiage;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ActivitySignIn extends AppCompatActivity implements View.OnClickListener {

    ImageButton imageBtnShowPassword;
    EditText editTextPassword;
    boolean motdepasseVisible = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sign_in);

        Button creerCompte = findViewById(R.id.btnSI);
        creerCompte.setOnClickListener(this);

        // Ecouteur pour le champ de saisi et l'icone du mot de passe
        editTextPassword = findViewById(R.id.chmpMDPSI);
        imageBtnShowPassword = findViewById(R.id.icBtnPsswrd);
        imageBtnShowPassword.setOnClickListener(this);

        // Régler la couleur de la barre d'état et la barre de navigation
        getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.barreEtat));
        getWindow().setNavigationBarColor(ContextCompat.getColor(this, R.color.barreEtat)); // Forcer la couleur de la barre de navigation


    }


    @Override
    public void onClick(View v) {
        EditText pseud = findViewById(R.id.pseudonyme);
        EditText log = findViewById(R.id.chmpLGNSI);
        EditText mdp = findViewById(R.id.chmpMDPSI);
        String pseudo = pseud.getText().toString().trim();
        String login = log.getText().toString().trim();
        String password = mdp.getText().toString().trim();


        if (v.getId() == R.id.btnSI) {

            Log.v("MYAPP", "1 click sur le bouton 'Créer un compte'");
            if(!isValidEmail(login) || pseudo.isEmpty() || password.isEmpty()){
                Toast.makeText(ActivitySignIn.this, "Un ou plusieurs champs invalid !", Toast.LENGTH_SHORT).show();
                return; // Arrêtez ici si l'email est invalide
            }
            else{

                Utilisateurs utilisateur = new Utilisateurs(pseudo, login,password);
                Intent NewUser = new Intent();
                NewUser.putExtra("NewUtilisateur",utilisateur);
                setResult(1, NewUser);
                finish();
            }


        }
        if(v.getId() == R.id.icBtnPsswrd){
            PasswordSwitchMode();
        }

    }

    //  Afficher ou masquer le mot de passe ainsi que l'icone associé
    private void PasswordSwitchMode(){
        if(motdepasseVisible){
            // Si le mot de passe est visible, le masquer
            editTextPassword.setInputType(InputType.TYPE_CLASS_TEXT |InputType.TYPE_TEXT_VARIATION_PASSWORD);
            motdepasseVisible = false;
            imageBtnShowPassword.setImageResource(R.drawable.ic_visibility_off);
        }
        else{
            // Si le mot de passe est masqué, le rendre visible
            editTextPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            motdepasseVisible = true;
            imageBtnShowPassword.setImageResource(R.drawable.ic_visibility_on);
        }
        // Pour déplacer le curseur à la fin du texte après le changement de type d'entrée
        editTextPassword.setSelection(editTextPassword.getText().length());

    }

    // Méthode pour vérifier la validité de l'email
    private boolean isValidEmail(String email) {
        String emailRegex = "^(?!.*\\.\\.)(?!.*--)(?!.*-\\.)[a-zA-Z0-9][a-zA-Z0-9._%+-]{0,62}[a-zA-Z0-9]@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
        Pattern pattern = Pattern.compile(emailRegex);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

}