package com.example.my_applicationmiage;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class Utilisateurs implements Parcelable {
    private String pseudonyme;
    private String login; // Adresse mail
    private String password;


    public Utilisateurs(String pseudo, String log, String mdp){
        this.pseudonyme = pseudo;
        this.login = log;
        this.password = mdp;
    }

    protected Utilisateurs(Parcel in) {
        pseudonyme = in.readString();
        login = in.readString();
        password = in.readString();
    }

    public static final Creator<Utilisateurs> CREATOR = new Creator<Utilisateurs>() {
        @Override
        public Utilisateurs createFromParcel(Parcel in) {
            return new Utilisateurs(in);
        }

        @Override
        public Utilisateurs[] newArray(int size) {
            return new Utilisateurs[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeString(pseudonyme);
        dest.writeString(login);
        dest.writeString(password);
    }


    public void setPseudonyme(String pseudo){
        this.pseudonyme = pseudo;
    }
    public String getPseudonyme(){
        return this.pseudonyme;
    }

    public void setLogin(String log){
        this.login = log;
    }
    public String getLogin(){
        return this.login;
    }


    public void setPassword(String mdp){
        this.password = mdp;
    }

    public String getPassword() {
        return password;
    }


}
