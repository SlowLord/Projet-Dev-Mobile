package com.example.my_applicationmiage;
import android.content.Context;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;

public class Persistance_Donnees {

    private static final String FICHIER_TYPE_ENTREPRISES = "entreprises.json";
    private static final Gson gson = new Gson();

    // Sauvegarder les utilisateurs
    public static void Sauvegarde_Utilisateurs(ArrayList<Utilisateurs> utilisateurs, ArrayList<String> nomsUtilisateurs, ArrayList<String> emailsUtilisateur, Context context) {
        try {
            FileWriter utilisateursWriter = new FileWriter(context.getFilesDir() + "/" + "utilisateurs.json");
            gson.toJson(utilisateurs, utilisateursWriter);
            utilisateursWriter.close();

            FileWriter nomsUtilisateursWriter = new FileWriter(context.getFilesDir() + "/" + "noms_utilisateurs.json");
            gson.toJson(nomsUtilisateurs, nomsUtilisateursWriter);
            nomsUtilisateursWriter.close();

            FileWriter emailsUtilisateurWriter = new FileWriter(context.getFilesDir() + "/" + "emails_utilisateur.json");
            gson.toJson(emailsUtilisateur, emailsUtilisateurWriter);
            emailsUtilisateurWriter.close();
        } catch (IOException e) {
            Log.e("SAVE", "Erreur lors de la sauvegarde des données Utilisateurs, NomsUtilisateurs et EMAIL_Utilisateur", e);
        }
    }

    // Méthode pour vider les fichiers utilisateurs
    public static void Vider_Fichiers_Utilisateurs(Context context) {
        try {
            FileWriter utilisateursWriter = new FileWriter(context.getFilesDir() + "/" + "utilisateurs.json");
            gson.toJson(new ArrayList<>(), utilisateursWriter);
            utilisateursWriter.close();

            FileWriter nomsUtilisateursWriter = new FileWriter(context.getFilesDir() + "/" + "noms_utilisateurs.json");
            gson.toJson(new ArrayList<>(), nomsUtilisateursWriter);
            nomsUtilisateursWriter.close();

            FileWriter emailsUtilisateurWriter = new FileWriter(context.getFilesDir() + "/" + "emails_utilisateur.json");
            gson.toJson(new ArrayList<>(), emailsUtilisateurWriter);
            emailsUtilisateurWriter.close();
        } catch (IOException e) {
            Log.e("SAVE", "Erreur lors de la vidange des fichiers Utilisateurs, NomsUtilisateurs et EMAIL_Utilisateur", e);
        }
    }
    // Chargement de la liste Utilisateurs
    public static ArrayList<Utilisateurs> Charger_Utilisateurs(Context context) {
        try {
            FileReader reader = new FileReader(context.getFilesDir() + "/" + "utilisateurs.json");
            Type listType = new TypeToken<ArrayList<Utilisateurs>>() {}.getType();
            ArrayList<Utilisateurs> utilisateurs = gson.fromJson(reader, listType);
            reader.close();
            return utilisateurs;
        } catch (IOException e) {
            Log.e("SAVE", "Erreur lors du chargement des données Utilisateurs", e);
            return new ArrayList<>();
        }
    }

    //Chargement de la liste Pseudonyme String
    public static ArrayList<String> Charger_NomsUtilisateurs(Context context) {
        try {
            FileReader reader = new FileReader(context.getFilesDir() + "/" + "noms_utilisateurs.json");
            Type listType = new TypeToken<ArrayList<String>>() {}.getType();
            ArrayList<String> nomsUtilisateurs = gson.fromJson(reader, listType);
            reader.close();
            return nomsUtilisateurs;
        } catch (IOException e) {
            Log.e("SAVE", "Erreur lors du chargement des données NomsUtilisateurs", e);
            return new ArrayList<>();
        }
    }

    //Chargement de la liste EMAIL string
    public static ArrayList<String> Charger_EMAIL_Utilisateur(Context context) {
        try {
            FileReader reader = new FileReader(context.getFilesDir() + "/" + "emails_utilisateur.json");
            Type listType = new TypeToken<ArrayList<String>>() {}.getType();
            ArrayList<String> emailsUtilisateur = gson.fromJson(reader, listType);
            reader.close();
            return emailsUtilisateur;
        } catch (IOException e) {
            Log.e("SAVE", "Erreur lors du chargement des données EMAIL_Utilisateur", e);
            return new ArrayList<>();
        }
    }


    // Sauvegarde des entreprises
    public static void Sauvegarde_Donnees(ArrayList<Entreprises> entreprises, Context context) {
        try {
            FileWriter entreprisesWriter = new FileWriter(context.getFilesDir() + "/" + FICHIER_TYPE_ENTREPRISES);
            gson.toJson(entreprises, entreprisesWriter);
            entreprisesWriter.close();
        } catch (IOException e) {
            Log.e("SAVE", "Erreur lors de la sauvegarde des données Entreprises et String", e);
        }
    }

    //Chargement des entreprises 'Entreprises
    public static ArrayList<Entreprises> Charger_Entreprises(Context context) {
        try {
            FileReader reader = new FileReader(context.getFilesDir() + "/" + FICHIER_TYPE_ENTREPRISES);
            Type listType = new TypeToken<ArrayList<Entreprises>>() {}.getType();
            ArrayList<Entreprises> entreprises = gson.fromJson(reader, listType);
            reader.close();
            return entreprises != null ? entreprises : new ArrayList<>();
        }
        catch (IOException e) {
            Log.e("SAVE", "Erreur lors du chargement des données type Entreprises", e);
            return new ArrayList<>();
        }
    }

}
